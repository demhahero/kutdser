<?php
if(!@include_once "../../api/dbconfig_direct.php")
  include_once "../api/dbconfig_direct.php";
?>
